#include<stdio.h>
void average(float[],float[]);
int main()
{
  int i;
  float phy[10],chem[10],avg[10];
  printf("\n Enter physics marks ");
  for(i=0;i<10;i++)
  {
    scanf("%f", &phy[i]);
  }
   printf("\n Enter Chemistry marks ");
  for(i=0;i<10;i++)
  {
    scanf("%f", &chem[i]);
  }
  average(phy,chem);
  return 0;
}
  void average(float temp1[],float temp2[])
  {
    float avg[10];
    int j;
    float sum[10];
    for(j=0;j<10;j++)
    {
      avg[j]=(temp1[j]+temp2[j])/2.0;
    }
    printf("\n Ther average marks of physics and chemistry is : ");
    for(j=0;j<10;j++)
    {
      printf("\n %.2f ",avg[j]);
    }
  }
