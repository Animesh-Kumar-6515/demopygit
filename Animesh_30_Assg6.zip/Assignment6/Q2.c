#include<stdio.h>
void statistics(int[],int);
void mySort(int[]);
void unique(int[]);
void display(int[]);

int main()
{
  int i,choose,arr[11];
  printf("\n Enter the elements ");
  for(i=0;i<11;i++)
  {
    scanf("%d",&arr[i]);
    
  }
  printf("\n Enter your choice:");
  scanf("%d",&choose);
  statistics(arr,choose);
  return 0;
}
void unique(int array[])
{
  int i,j,count=1;
  for(i=0;i<11;i++)
  {
    for(j=0;j<11;j++)
    {
      if(array[i]==array[j] && i!=j)
      {
        break;
      }
    }
      if(j==11)
      {
        printf("%d",array[i]);
      }
    }
}
void mySort(int number[])
{
  int i,j,temp;
       for (i = 0; i < 11; ++i) 
        {
          for (j = i + 1; j < 11; ++j)
            {
              if (number[i] > number[j]) 
                {
                  temp =  number[i];
                  number[i] = number[j];
                  number[j] = temp;
                }

            }
         }
}
void statistics(int arr[],int choice)
{
  float ans;
  int maxValue = 0, maxCount = 0, i, j,n;
  switch(choice)
  {
    case 1 : 
      for(i=0;i<11;i++)
      {
         ans = ans + arr[i];
      }
     printf("The mean  is %f",(ans / 11));
      break;
    case 2:
       mySort(arr);
       n = 11;
       n = (n+1) / 2 - 1;     

       printf("Median of the array is %d \n", arr[n]);
       break;
    case 3:
      for(i=0;i<n;i++)
      {
        int count =0;
      for(j=0;j<n;j++)
      {
        if(arr[i]==arr[j])
          ++count;
      }
      if(count>maxCount){
        maxCount=count;
        maxValue=arr[i];
        
      }
      }
      printf("\n Mode of the array is %d ",maxValue);
      break;
      defult:
      printf("Wrong choice!!");
  }
}
  